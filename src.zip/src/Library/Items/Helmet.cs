namespace Ucu.Poo.RoleplayGame;

public class Helmet
{
    public int DefenseValue
    {
        get
        {
            return 18;
        }
    }
}
