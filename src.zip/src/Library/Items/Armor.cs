namespace Ucu.Poo.RoleplayGame;

public class Armor
{
    public int DefenseValue
    {
        get
        {
            return 25;
        }
    }
}
