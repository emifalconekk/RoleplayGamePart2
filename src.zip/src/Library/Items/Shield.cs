namespace Ucu.Poo.RoleplayGame;

public class Shield
{
    public int DefenseValue
    {
        get
        {
            return 14;
        }
    }
}
