namespace Ucu.Poo.RoleplayGame;

public class Axe
{
    public int AttackValue 
    {
        get
        {
            return 25;
        } 
    }
}
