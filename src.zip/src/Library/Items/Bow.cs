namespace Ucu.Poo.RoleplayGame;

public class Bow
{
    public int AttackValue 
    {
        get
        {
            return 15;
        } 
    }
}
