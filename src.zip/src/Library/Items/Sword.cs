namespace Ucu.Poo.RoleplayGame;

public class Sword
{
    public int AttackValue 
    {
        get
        {
            return 20;
        } 
    }
}
